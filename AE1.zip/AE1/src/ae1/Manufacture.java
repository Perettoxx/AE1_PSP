package ae1;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Classe que representa el procés de fabricació de peces Tetris.
 * 
 * <p>La classe permet la fabricació de peces Tetris amb opcions com desar els resultats en un fitxer.</p>
 */
public class Manufacture {
    private static List<String> pecesFabricades = new ArrayList<>();
    private static Object lock = new Object();

    
    /**
     * Inicia el procés de fabricació de peces Tetris amb les opcions especificades.
     *
     * @param tipusPeces Un array de strings que conté els tipus de les peces Tetris a fabricar.
     * @param quantitatsPeces Un array de strings que conté les quantitats corresponents a cada tipus de peça.
     * @param desarEnFitxer Indica si es desaran les peces en un fitxer.
     * @param nomFitxer Nom del fitxer en el qual es desaran les peces (opcional).
     */
    public static void manufacturePieces(String[] tipusPeces, String[] quantitatsPeces, boolean desarEnFitxer, String nomFitxer) {
        int numMaquines = 8;
        ExecutorService executor = Executors.newFixedThreadPool(numMaquines);

        Runnable tasca = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < tipusPeces.length; i++) {
                    String tipusPeca = tipusPeces[i];
                    int quantitatPeces = Integer.parseInt(quantitatsPeces[i]);

                    for (int j = 0; j < quantitatPeces; j++) {
                        long tempsManufactura = obtenirTempsManufactura(tipusPeca);
                        procesFabricacio(tempsManufactura);

                        String nomPeca = tipusPeca + "_" + obtenirSegellTemps();
                        System.out.println(nomPeca);

                        synchronized (lock) {
                            pecesFabricades.add(nomPeca);
                        }
                    }
                }
            }
        };

        executor.execute(tasca);

        executor.shutdown();

        while (!executor.isTerminated()) {
            // Espera fins que tots els fils s'hagen completat.
        }

        if (desarEnFitxer) {
            desarPecesEnFitxer(nomFitxer);
        }
    }

    /**
     * Obté el temps de fabricació per al tipus de peça especificat.
     *
     * @param tipusPeca Tipus de la peça Tetris.
     * @return El temps de fabricació en milisegons.
     */
    private static long obtenirTempsManufactura(String tipusPeca) {
        switch (tipusPeca) {
            case "I":
                return 1000;
            case "O":
                return 2000;
            case "T":
                return 3000;
            case "J":
            case "L":
                return 4000;
            case "S":
            case "Z":
                return 5000;
            default:
                return 0;
        }
    }

    /**
     * Simula el procés de fabricació ocupant la màquina durant el temps especificat.
     *
     * @param tempsFabricacio El temps de fabricació en milisegons.
     */
    public static void procesFabricacio(long tempsFabricacio) {
        long tempsInici = System.currentTimeMillis();
        long tempsFinal = tempsInici + tempsFabricacio;
        int iteracions = 0;
        while (System.currentTimeMillis() < tempsFinal) {
            iteracions++;
        }
    }

    /**
     * Obté el segell de temps actual en el format especificat.
     *
     * @return El segell de temps en format "yyyyMMdd_HHmmss".
     */
    private static String obtenirSegellTemps() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        Date data = new Date();
        return sdf.format(data);
    }

    /**
     * Desa les peces fabricades en un fitxer amb el nom especificat.
     *
     * @param nomFitxer Nom del fitxer en el qual es desaran les peces.
     */
    private static void desarPecesEnFitxer(String nomFitxer) {
        try {
            PrintWriter escriptor = new PrintWriter(new FileWriter("LOG_" + nomFitxer + ".txt"));
            for (String peca : pecesFabricades) {
                escriptor.println(peca);
            }
            escriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
