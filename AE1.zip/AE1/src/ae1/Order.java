package ae1;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Order extends JFrame {
    private JPanel panel;
    private JTextField pieceTypeField;
    private JTextField pieceQuantityField;
    private JCheckBox saveToFileCheckBox;
    private JTextField fileNameField;
    private JButton manufactureButton;

    public Order() {
        panel = new JPanel();
        pieceTypeField = new JTextField(10);
        pieceTypeField.setBounds(200, 30, 130, 26);
        pieceQuantityField = new JTextField(10);
        pieceQuantityField.setBounds(200, 58, 130, 26);
        saveToFileCheckBox = new JCheckBox("Guardar en l'arxiu");
        saveToFileCheckBox.setBounds(111, 142, 154, 23);
        fileNameField = new JTextField(10);
        fileNameField.setBounds(200, 85, 130, 26);
        manufactureButton = new JButton("Fabricar");
        manufactureButton.setBounds(145, 190, 94, 29);

        saveToFileCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fileNameField.setEnabled(saveToFileCheckBox.isSelected());
            }
        });

        manufactureButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pieceTypesInput = pieceTypeField.getText().replaceAll("\\s", "");
                String pieceQuantitiesInput = pieceQuantityField.getText().replaceAll("\\s", "");
                boolean saveToFile = saveToFileCheckBox.isSelected();
                String fileName = fileNameField.getText();

                String[] pieceTypes = pieceTypesInput.split(",");
                String[] pieceQuantities = pieceQuantitiesInput.split(",");

                Manufacture.manufacturePieces(pieceTypes, pieceQuantities, saveToFile, fileName);
            }
        });

        panel.setLayout(null);

        JLabel lblTipus = new JLabel("Tipus:");
        lblTipus.setBounds(56, 35, 88, 16);
        panel.add(lblTipus);
        panel.add(pieceTypeField);
        JLabel lblQuantitat = new JLabel("Quantitat");
        lblQuantitat.setBounds(56, 63, 60, 16);
        panel.add(lblQuantitat);
        panel.add(pieceQuantityField);
        panel.add(saveToFileCheckBox);
        JLabel lblNomDeLarxiu = new JLabel("Nom de l'arxiu");
        lblNomDeLarxiu.setBounds(56, 90, 123, 16);
        panel.add(lblNomDeLarxiu);
        panel.add(fileNameField);
        panel.add(manufactureButton);

        getContentPane().add(panel);
        this.setTitle("Tetris");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Order();
            }
        });
    }
}
