/**
 * 
 */
/**
 * 
 */
module AE1 {
	requires java.desktop;
}